/********************************************************************* 
** Author: Katheen Thurmes
** Date: 9 Dec., 2019
** Description: main launches the Final Project program.
*********************************************************************/
#include "Menu.hpp"

int main()
{
    Menu m;
    m.welcome();
}