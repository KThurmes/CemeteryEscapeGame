#ifndef GETNUMBERBETWEEN_HPP
#define GETNUMBERBETWEEN_HPP

int getNumberBetween(int, int);
int getValidInt();

#endif