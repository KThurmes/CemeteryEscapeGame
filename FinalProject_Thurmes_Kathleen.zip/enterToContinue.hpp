/********************************************************************* 
** Author: Katheen Thurmes
** Date: 9 Dec., 2019
** Description: enterToContinue contains a function that requests 
that the user press "enter" to continue.
*********************************************************************/

#ifndef ENTERTOCONTINUE_HPP
#define ENTERTOCONTINUE_HPP

void enterToContinue();

#endif